package MazebotSim;

import java.util.concurrent.TimeUnit;

import lejos.robotics.RegulatedMotor;
import lejos.robotics.RegulatedMotorListener;

public class SimRegulatedMotor implements lejos.robotics.RegulatedMotor {
	
	private static final double TOLERANCE = 1e-4;
	
	private final float MAX_SPEED = 760f;
	
	private enum MODES { FORWARD, BACKWARD, ROTATE, FLOATING, STOP }; 
	
	private SimTachometer tacho = new SimTachometer();
	private MODES mode = MODES.FLOATING;

	private boolean isSynchronizing = false;
	private double speedLastSet = 0; // in rad/s
	
	private RegulatedMotorListener listener = null;
	private RegulatedMotor[] syncList;
	
	//Function for the Simulation:
	/**
	 * 
	 * @param deltaTime
	 * @return The rotation performed within the timeDelta in rad
	 */
	public double performSimulationStep(double deltaTime) {
		double dTurn;
		synchronized (tacho) {
			dTurn = tacho.performSimulationStep(deltaTime);
		}
		if (tacho.hasReachedGoal()) {
			// TODO: Listener
		}
		return dTurn;
	}
	
	public double getRealTachoCount() {
		return tacho.getTachoCount();
	}
	
	//Public Regulated Motor Calls
	@Override
	public int getRotationSpeed() {
		return (int) Math.round(Math.toDegrees(tacho.getSpeed()));
	}
	
	@Override
	public void flt(boolean immideateReturn) {
		flt(false);
	}
	
	@Override
	public void flt() {
		mode = MODES.FLOATING;
	}
	
	@Override
	public void startSynchronization() {
		isSynchronizing = true;
		if (syncList != null) {
			for (RegulatedMotor motor : syncList) {
				motor.startSynchronization();
			}
		}
	}
	
	@Override
	public void endSynchronization() {
		isSynchronizing = false;
		go();
		if (syncList != null) {
			for (RegulatedMotor motor : syncList) {
				motor.endSynchronization();
			}
		}
	}
	
	@Override
	public void stop(boolean immediateReturn) {
		synchronized (tacho) {
			tacho.setSpeed(0);
			tacho.removeGoal();
			mode = MODES.STOP;
		}
		synchronized(this) {
			while (Math.abs(tacho.getSpeed()) > TOLERANCE && !immediateReturn) {
				try {
					wait(1l);
				} catch (InterruptedException e) {
					// nothing to do;
				}
			}			
		}
	}
	
	public void stop() {
		stop(false);
	}
	
	
	@Override
	public void waitComplete() {
		while (tacho.tachoHasGoal()) {
			try {
				TimeUnit.MILLISECONDS.sleep(1);
			} catch (InterruptedException ex) {
				
			}
		}
	}
	
	@Override
	public void rotate(int angle, boolean immediateReturn) {
		mode = MODES.ROTATE;
		double angleInRad = Math.toRadians(angle);
		synchronized (tacho) {
			tacho.setGoalRelative(angleInRad);
		}
		if (! isSynchronizing) {
			go();
		}
		if (!immediateReturn && !isSynchronizing) {
			waitComplete();
		}
	}
	
	@Override
	public void rotate(int angle) {
		rotate(angle, false);
	}
	
	@Override
	public void rotateTo(int limitAngle) {
		rotateTo(limitAngle, false);
	}
	
	@Override
	public void rotateTo(int limitAngle, boolean immediateReturn) {
		mode = MODES.ROTATE;
		synchronized (tacho) {
			tacho.setGoal(limitAngle);
		}
		if (! isSynchronizing) {
			go();
		}
		if (!immediateReturn) {
			waitComplete();
		}
	}
	
	private void go() {
		double actualSpeed = speedLastSet;
		switch (mode) {
			case FORWARD:
				actualSpeed = Math.abs(speedLastSet);
				break;
			case BACKWARD:
				actualSpeed = -Math.abs(speedLastSet);
				break;
			case ROTATE:
				if (tacho.getGoal() > tacho.getTachoCount()) {
					actualSpeed = Math.abs(actualSpeed);
				} else {
					actualSpeed = -Math.abs(actualSpeed);
				}
				break;
			case STOP:
				actualSpeed = 0;
				break;
			case FLOATING:
				actualSpeed = 0;
			default:
				break;
		}
		
		synchronized (tacho) {
			tacho.setSpeed(actualSpeed);
		}
	}
	
	@Override
	public int getLimitAngle() {
		return (int) Math.round(Math.toRadians(tacho.getGoal()));
	}
	
	@Override
	public void setSpeed(int speed) {
		double inRad = Math.toRadians(speed);
		speedLastSet = inRad;
		if ( ! isSynchronizing ) {
			go();
		}
	}
	
	@Override
	public int getSpeed() {
		double speed;
		synchronized (tacho) {
			speed = tacho.getSpeed();
		}
		return (int) Math.round(Math.toDegrees(speed));
	}
	
	@Override
	public float getMaxSpeed() {
		return MAX_SPEED;
	}
	
	@Override
	public boolean isStalled() {
		return false;
	}
	
	@Override
	public void setStallThreshold(int error, int time) {
		// TODO: Implement stalling
	}
	
	@Override
	public void setAcceleration(int accleleration) {
		// TODO: Implement acceleration
	}
	
	@Override
	public void synchronizeWith(RegulatedMotor[] syncList) {
		this.syncList = syncList;
	}
	
	@Override
	public void close() {
		// TODO: Is there something to do here?
	}
	
	@Override
	public void addListener(RegulatedMotorListener listener) {
		this.listener = listener;
	}
	
	@Override
	public RegulatedMotorListener removeListener() {
		RegulatedMotorListener l = listener;
		listener = null;
		return l;
	}
	
	@Override
	public void resetTachoCount() {
		synchronized(tacho) {
			tacho.resetTachoCount();
		}
	}


	@Override
	public void forward() {
		mode = MODES.FORWARD;
		if (!isSynchronizing) {
			go();
		}
	}


	@Override
	public void backward() {
		mode = MODES.BACKWARD;
		if (!isSynchronizing) {
			go();
		}		
	}


	@Override
	public boolean isMoving() {
		return tacho.getSpeed() != 0 || (tacho.getGoal() - tacho.getTachoCount()) > 1 ;
	}


	@Override
	public int getTachoCount() {
		double inDegrees = Math.toDegrees(tacho.getTachoCount());
		return (int) Math.round(inDegrees);
	}
		
}
