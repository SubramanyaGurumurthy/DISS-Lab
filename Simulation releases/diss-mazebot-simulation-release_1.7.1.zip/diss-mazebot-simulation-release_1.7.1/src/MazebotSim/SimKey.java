package MazebotSim;

import java.util.ArrayList;
import java.util.List;

import lejos.hardware.Key;
import lejos.hardware.KeyListener;

public class SimKey implements Key {
	
	public final static int KEY_RELEASED = 0;
	public final static int KEY_PRESSED = 1;
	public final static int KEY_PRESSED_AND_RELEASED = 2;

	private int ID;
	private String name;
	private boolean down;
	private List<KeyListener> listeners;
	
	public SimKey(int id, String name) {
		this.ID = id;
		down = false;
		this.name = name;
		listeners = new ArrayList<KeyListener>();
	}
	
	@Override
	public void addKeyListener(KeyListener arg0) {
		listeners.add(arg0);
	}

	@Override
	public int getId() {
		return ID;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public boolean isDown() {
		return down;
	}

	@Override
	public boolean isUp() {
		return !down;
	}

	@Override
	public void simulateEvent(int event) {
		switch(event) {
		case KEY_PRESSED:
			if (!down) {
				down = true;
				notifyPressEvent();
			}
			break;
		case KEY_RELEASED:
			if (down) {
				down = false;
				notifyReleaseEvent();
			}
			break;
		case KEY_PRESSED_AND_RELEASED:
			down = false;
			break;
		}
	}

	@Override
	public void waitForPress() {
		while (!down) {
			try {
				wait(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void waitForPressAndRelease() {
		waitForPress();
		while (down) {
			try {
				wait(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	private void notifyReleaseEvent() {
		for (KeyListener l : listeners) {
			l.keyReleased(this);
		}	
	}
	
	private void notifyPressEvent() {
		for (KeyListener l : listeners) {
			l.keyPressed(this);
		}	
	}
}
