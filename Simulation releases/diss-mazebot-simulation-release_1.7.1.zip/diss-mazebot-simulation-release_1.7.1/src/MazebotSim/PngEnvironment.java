package MazebotSim;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class PngEnvironment implements MazeEnvironment {

	private BufferedImage maze;
	private double pixelWidth;
	private double pixelHeight;
	
	public PngEnvironment(BufferedImage pngImage, double width, double height) {
		maze = pngImage;
		pixelWidth = width / maze.getWidth();
		pixelHeight = height / maze.getHeight();
	}
		
	@Override
	public double getDistanceMeasurement(RobotPosition pos) {
		RobotPosition imageCoordinates = transformWorldToImageCoordinates(pos); 
		PixelPosition tile = traceToNearestOpaqueTile(imageCoordinates);
		if (tile != null) {
			double dx = imageCoordinates.x - tile.x*pixelWidth;
			double dy = imageCoordinates.y - tile.y*pixelHeight;
			return Math.sqrt(dx*dx + dy*dy);		
		}
		else {
			return Double.POSITIVE_INFINITY;
		}
	}

	@Override
	public int[] getRgbColorMeasurement(RobotPosition pos) {
		PixelPosition tile = traceToNearestOpaqueTile(transformWorldToImageCoordinates(pos));
		if (tile != null) {
			Color c = new Color(maze.getRGB(tile.x, tile.y));
			int[] result = new int[] {c.getRed(), c.getGreen(), c.getBlue()};
			return result;
		}
		else {
			return new int[] { 128, 128, 128 };
		}
	}
	
	public double getWidthInRealWorldCoordinates() {
		return maze.getWidth() * pixelWidth;
	}
	
	public double getHeightInRealWorldCoordinates() {
		return maze.getHeight() * pixelHeight;
	}
	
	public BufferedImage getMazeImage() {
		return maze;
	}
	
	public double getAspectRatio() {
		return (double) maze.getWidth() / (double) maze.getHeight();
	}
	
	private PixelPosition traceToNearestOpaqueTile(RobotPosition pos) {
		double tileDiagonal = Math.sqrt(pixelWidth*pixelWidth + pixelHeight*pixelHeight);
		double dx = Math.cos(pos.orientation) * tileDiagonal / 2;
		double dy = -Math.sin(pos.orientation) * tileDiagonal / 2;
		
		boolean outOfScope = false;
		int i = 0;
		while (!outOfScope) {
			double x = pos.x + i*dx;
			double y = pos.y + i*dy;
			PixelPosition targetTile = reducePositionToTile(x, y);
			
			boolean aboveZero = targetTile.x >= 0 && targetTile.y >= 0;
			boolean belowMaxSize = targetTile.x < maze.getWidth() && targetTile.y < maze.getHeight();
			
			if (aboveZero && belowMaxSize ) {
				Color pixelColor = new Color(maze.getRGB(targetTile.x, targetTile.y), true);
				if (pixelColor.getAlpha() == 255) {
					return targetTile;
				}
			}
			else {
				outOfScope = true;
			}
			i++;
		}
		return null;
	}
	
	private PixelPosition reducePositionToTile(double x, double y) {
		int xTile = (int) (x / pixelWidth);
		int yTile = (int) (y / pixelHeight);
		return new PixelPosition(xTile, yTile);
	}
	
	private RobotPosition transformWorldToImageCoordinates(RobotPosition pos) {
		RobotPosition copy = new RobotPosition();
		copy.x = pos.x + maze.getWidth() * pixelWidth / 2;
		copy.y =  maze.getHeight() * pixelHeight/2 + pos.y;
		copy.orientation = pos.orientation;
		return copy;
	}
	
	private class PixelPosition {
		
		public int x;
		public int y;
		
		public PixelPosition(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}
	
	

}
