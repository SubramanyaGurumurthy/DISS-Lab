package MazebotSim;

import java.util.HashSet;
import java.util.Set;

import lejos.hardware.port.Port;
import lejos.hardware.port.PortException;
import lejos.hardware.port.TachoMotorPort;

public class PortManagement {
	
	private Set<String> portUsed = new HashSet<String>(); 

	public void open(Port p) {
		open(p.getName());
	}
	
	public void open(TachoMotorPort p) {
		open(p.getName());
	}
	
	public void open(String portName) {
		if (portUsed.contains(portName)) {
			throw new PortException("Port already used: Port " + portName);
		}
		portUsed.add(portName);
	}
	
	public void close(Port p) {
		close(p.getName());
	}
	
	public void close(String portName) {
		portUsed.remove(portName);
	}

}
