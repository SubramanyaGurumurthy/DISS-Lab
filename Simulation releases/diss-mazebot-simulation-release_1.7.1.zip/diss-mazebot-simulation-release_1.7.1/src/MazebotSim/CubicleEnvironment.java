package MazebotSim;

public class CubicleEnvironment implements MazeEnvironment {

	private double width;
	private double height;
	
	public CubicleEnvironment(double width, double height) {
		this.width = width;
		this.height = height;
	}
	
	public double getWidth() {
		return width;
	}

	public double getHeight() {
		return height;
	}
	
	public double getAspectRatio() {
		return getWidth() / getHeight();
	}

	@Override
	public double getDistanceMeasurement(RobotPosition pos) {
		double horizontalConjunction = getHorizontalConjunction(pos);
		double verticalConjunction = getVerticalConjunction(pos);
		return Math.min(horizontalConjunction, verticalConjunction);		
	}

	@Override
	public int[] getRgbColorMeasurement(RobotPosition pos) {
		// TODO Auto-generated method stub
		return new int[] {255, 255, 255};
	}
	
	private double getHorizontalConjunction(RobotPosition pos) {
		double phi;
		double dy;
		if (pos.getNormalizedOrientation() > 0) {
			phi = Math.abs(pos.orientation - Math.PI/2);
			dy = (height/2) - pos.y;
		}
		else {
			phi = Math.abs(pos.orientation + Math.PI/2);
			dy = (height/2) + pos.y;
		}
		return dy / Math.cos(phi);
	}
	
	private double getVerticalConjunction(RobotPosition pos) {
		double phi;
		double dx;
		if (Math.abs(pos.getNormalizedOrientation()) > Math.PI/2) {
			phi = Math.abs(pos.orientation) - Math.PI;
			dx = (width/2) + pos.x;
		}
		else {
			phi = Math.abs(pos.orientation);
			dx = (width/2) - pos.x;
		}
		return dx / Math.cos(phi);
	}
}
