package MazebotSim;

import lejos.hardware.sensor.BaseSensor;

public class BaseSimulatedSensor extends BaseSensor {
	
	protected SampleListener listener;
	
	public interface SampleListener {
		float[] onSampleRequest(String mode);
	}
	
	void setSampleListener(SampleListener listener) {
		this.listener = listener;
	}
	
}
