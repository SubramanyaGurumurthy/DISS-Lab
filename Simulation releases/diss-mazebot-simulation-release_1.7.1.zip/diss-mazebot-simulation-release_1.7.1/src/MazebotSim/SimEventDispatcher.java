package MazebotSim;

public interface SimEventDispatcher {

	void onTogglePause();
	
	void onSpeedIncrease();
	
	void onSpeedDecrease();
	
	double getSpeedFactor();
	
	boolean isPaused();
}
