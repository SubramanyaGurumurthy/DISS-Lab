package MazebotSim;

public interface MazeEnvironment {

	public double getDistanceMeasurement(RobotPosition pos);
	public int[] getRgbColorMeasurement(RobotPosition pos);
	public double getAspectRatio();
}
