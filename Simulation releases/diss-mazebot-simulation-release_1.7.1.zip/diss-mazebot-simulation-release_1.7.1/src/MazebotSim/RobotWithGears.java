package MazebotSim;

public class RobotWithGears implements IMotorToRobotTranslator{

	private RobotParameters params;
	private RobotPosition pos;
	
	public RobotWithGears(RobotParameters params) {
		this.params = params;
	}
	
	@Override
	public RobotPosition setMotorMovements(double[] movements, RobotPosition currentPosition) {
		if (movements.length < 2) {
			throw new IllegalArgumentException("This robot implementation has two motors");
		}
		
		pos = new RobotPosition(currentPosition);
		double motorLeftTurn = movements[0];
		double motorRightTurn = movements[1];
		MovementSplitter s = new MovementSplitter(motorLeftTurn, motorRightTurn);
		turn( s.getTurnComponent());
		translate(s.getTranslationComponent());
		return pos;
	}
	
	private void turn(double motorDelta) {
		double robotAngle = -motorDelta * params.getWheelDiameter() / ( params.getAxisDiameter() * params.getGearTransmissionRatio());
		pos.turn(robotAngle);
	}
	
	private void translate(double motorDelta) {
		double turnAngleAtWheel = motorDelta / params.getGearTransmissionRatio();
		double distanceTravelled = turnAngleAtWheel / 2 * params.getWheelDiameter();
		pos.driveStraight(distanceTravelled);
	}

}
