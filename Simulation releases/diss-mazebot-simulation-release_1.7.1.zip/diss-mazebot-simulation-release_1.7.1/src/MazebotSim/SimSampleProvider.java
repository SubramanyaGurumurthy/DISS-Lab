package MazebotSim;

import lejos.hardware.sensor.SensorMode;
import lejos.robotics.SampleProvider;

public class SimSampleProvider implements SampleProvider, SensorMode {

	public int numSamples;
	public float[] samples;
	private String name;
	
	public SimSampleProvider(int numSamples, String name) {
		this.numSamples = numSamples;
		samples = new float[numSamples];
		this.name = name;
	}
	
	public void setSamples(float[] samples) {
		if (samples.length != numSamples) {
			throw new IllegalArgumentException();
		}
		this.samples = samples;
	}

	@Override
	public int sampleSize() {
		return numSamples;
	}

	@Override
	public void fetchSample(float[] sample, int offset) {
		for (int i = 0; i < numSamples; i++) {
			sample[i + offset] = this.samples[i];
		}
	}

	@Override
	public String getName() {
		return name;
	}
	
}
