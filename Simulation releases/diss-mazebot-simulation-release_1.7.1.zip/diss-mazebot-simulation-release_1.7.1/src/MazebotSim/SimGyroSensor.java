package MazebotSim;

public class SimGyroSensor {

	private double simulationStep;
	private double previousOrientation = 0;
	private double rate = 0;
	private double lagParameter = 0;
	
	public SimGyroSensor(double simulationStep, double lag) {
		this.simulationStep = simulationStep;
		this.lagParameter = lag;
	}
	
	public void setOrientation(double orientation) {
		double nextOrientation = ( 1 - lagParameter)*orientation + lagParameter * previousOrientation;
		rate = (nextOrientation - previousOrientation) / simulationStep;
		previousOrientation = nextOrientation;
	}
	
	public float getOrientation() {
		return (float) Math.toDegrees(previousOrientation);
	}
	
	public float getRate() {
		return (float) Math.toDegrees(rate);
	}	
}
