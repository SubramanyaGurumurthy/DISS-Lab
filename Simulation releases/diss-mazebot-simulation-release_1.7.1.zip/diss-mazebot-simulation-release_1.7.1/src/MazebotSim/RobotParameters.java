package MazebotSim;

public class RobotParameters {

	private double wheelDiameter = 0.0537;
	private double axisDiameter = 0.11;
	private double gearTransmissionRatio = -3;
	private double usSensorOffset = 0.045;
	
	public double getWheelDiameter() {
		return wheelDiameter;
	}
	public void setWheelDiameter(double wheelDiameter) {
		this.wheelDiameter = wheelDiameter;
	}
	public double getAxisDiameter() {
		return axisDiameter;
	}
	public void setAxisDiameter(double axisDiameter) {
		this.axisDiameter = axisDiameter;
	}
	
	/**
	 * @return
	 */
	public double getGearTransmissionRatio() {
		return gearTransmissionRatio;
	}
	
	/**Sets the transmission ratio of the gears. Keep in mind that 
	 * this is usually negative, if only two cogs are involved
	 * 
	 * @param gearTransmissionRatio in meters
	 */
	public void setGearTransmissionRatio(double gearTransmissionRatio) {
		this.gearTransmissionRatio = gearTransmissionRatio;
	}
	public double getUsSensorOffset() {
		return usSensorOffset;
	}
	public void setUsSensorOffset(double usSensorOffset) {
		this.usSensorOffset = usSensorOffset;
	}
	
}
