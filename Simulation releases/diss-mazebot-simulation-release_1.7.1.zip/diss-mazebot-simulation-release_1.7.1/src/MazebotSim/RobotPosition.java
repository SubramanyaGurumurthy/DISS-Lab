package MazebotSim;

public class RobotPosition {
	public double x = 0;
	public double y = 0; 
	public double orientation = 0;
	
	public RobotPosition() {
		
	}
	
	public RobotPosition(RobotPosition other) {
		x = other.x;
		y = other.y;
		orientation = other.orientation;
	}
	
	public void driveStraight(double dist) {
		x += Math.cos(orientation) * dist;
		y -= Math.sin(orientation) * dist;
	}
	
	public void turn(double angle) {
		orientation += angle;
	}
	
	public double getNormalizedOrientation() {
		return normalize(orientation);
	}
	
	private double normalize(double angle) {
		while (angle > Math.PI) {
			angle -= 2*Math.PI;
		}
		while (angle < -Math.PI) {
			angle += 2*Math.PI;
		}
		return angle;
	}
	
}
