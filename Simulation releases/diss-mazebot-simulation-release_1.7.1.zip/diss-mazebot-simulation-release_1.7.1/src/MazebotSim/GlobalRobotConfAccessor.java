package MazebotSim;

public class GlobalRobotConfAccessor {

	private static SimulatedMazebot robot;
	
	public static SimulatedMazebot getRobot() {
		return robot;
	}
	
	public static void setRobot(SimulatedMazebot conf) {
		robot = conf;
	}
}
