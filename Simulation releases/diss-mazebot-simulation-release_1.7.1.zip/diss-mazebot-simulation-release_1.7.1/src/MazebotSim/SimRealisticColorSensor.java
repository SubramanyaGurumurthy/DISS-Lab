package MazebotSim;

public class SimRealisticColorSensor {

	final double criticalDist = 0.05;
	int[] rgb;
	
	public SimRealisticColorSensor(int[] rgb, double distance) {
		this.rgb = calcualateDistanceMix(rgb, distance);
	}
	
	private int[] calcualateDistanceMix(int[] rgb, double distance) {
		int[] withDist = new int[3];
		double factor = Math.min(1, criticalDist / distance);
		for (int i = 0; i < 3; i++) {
			withDist[i] = (int) (factor*rgb[i] + (1-factor)*128);
		}
		return withDist;
	}
	
	public float[] getRgbColors() {
		float[] asFloat = new float[] {((float)rgb[0])/255, ((float)rgb[1])/255, ((float)rgb[2])/255};
		return asFloat;
	}
	
	public float[] getColorId() {
		final int[][] colors = new int[][] {
			new int[] {255,	0,	0},
			new int[] {0,	255,	0},
			new int[] {0,	0,	255},
			new int[] {255,	255,	0},
			new int[] {255,	255, 255},
			new int[] {102,	51,	0},	
			new int[] {102, 51, 0},
			new int[] {0,	0,	0},
		};
		
		double minDist = Double.POSITIVE_INFINITY;
		int minIndex = -1;
		
		for (int i = 0; i < colors.length; i++) {
			double dist = getDistance(rgb, colors[i]);
			if (dist < minDist) {
				minDist = dist;
				minIndex = i;
			}
		}
		
		if (minDist < 100) {
			return new float[] {minIndex};
		}
		return new float[] {-1};
	}
	
	private double getDistance(int[] rgb1, int[] rgb2) {
		int dR = rgb1[0] - rgb2[0];
		int dG = rgb1[1] - rgb2[1];
		int dB = rgb1[2] - rgb2[2];
		return Math.sqrt(dR*dR + dG*dG + dB*dB);
	}
}
