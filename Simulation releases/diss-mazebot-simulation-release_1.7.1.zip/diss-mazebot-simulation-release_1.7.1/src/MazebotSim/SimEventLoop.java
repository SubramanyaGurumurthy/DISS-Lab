package MazebotSim;

import java.util.concurrent.TimeUnit;


public class SimEventLoop implements Runnable {
		
	private boolean stop = false;
	private float timestep;
	private float speedScale = 1;
	private boolean pause = false;
	private boolean debug = false;

	private SimulatedMazebot mazebot;
	private MazeEnvironment env;
	private SimGyroSensor gyro;
	long totalTimesteps;

	public SimEventLoop(SimulatedMazebot mazebot, MazeEnvironment env, float timestep) {
		this.mazebot = mazebot;
		this.timestep = timestep;
		this.env = env;
		this.gyro = new SimGyroSensor(timestep, 0.99);
	}
	
	public void start() {
		this.stop = false;
		totalTimesteps = 0;
		Thread t = new Thread(this);
		t.start();
	}
	
	public void stop() {
		this.stop = true;
	}
	
	public void run() {
		while (!stop) {
			if (! pause) {
				performSimulationStep();
			}
			try {
				long sleepTimeUs = (long) (timestep * 1e6);
				TimeUnit.MICROSECONDS.sleep(sleepTimeUs);
			} catch (InterruptedException ex) {
				System.err.println("Error during simulation step: ");
				System.err.print(ex.getMessage());
			}
		}
	}
	
	public void performSimulationStep() {
		totalTimesteps++;
		if (debug && totalTimesteps % 200 == 0) {
			System.out.println("Orientation: " + mazebot.getPos().orientation/(2*Math.PI)*360 + ", Gyro: " + gyro.getOrientation());
		}
		moveMotors();
		updateSensors();
	}
	
	public void setSpeedScale(float speedScale) {
		this.speedScale = speedScale;
	}

	private void moveMotors() {
		double dL = mazebot.getMotorLeft().performSimulationStep(timestep * speedScale);
		double dR = mazebot.getMotorRight().performSimulationStep(timestep * speedScale);
		
		double[] motorMovements = new double[] {dL, dR};
		IMotorToRobotTranslator motorTranslator = new RobotWithGears(mazebot.getRobotParameters());
		RobotPosition newPos = motorTranslator.setMotorMovements(motorMovements, mazebot.getPos());
		mazebot.setPos(newPos);
	}
	
	private void updateSensors() {
		double usSensorOffset = mazebot.getRobotParameters().getUsSensorOffset();
		double dist = env.getDistanceMeasurement(mazebot.getPos()) - usSensorOffset;
		dist = Math.max(0, dist); // To prevent negative values if Robot close to wall than the offset
		mazebot.getDistanceSensor().setSamples(new float[] {(float)dist});
		
		gyro.setOrientation(mazebot.getPos().orientation); 
		int orientation = (int) Math.round(gyro.getOrientation());
		mazebot.getGyroOrientation().setSamples(new float[] {(float) orientation});
		mazebot.getGyroRate().setSamples(new float[] {gyro.getRate()});
		
		int[] color = env.getRgbColorMeasurement(mazebot.getPos());
		SimRealisticColorSensor colorSensor = new SimRealisticColorSensor(color, dist);
		mazebot.getRGBColorSensor().setSamples(colorSensor.getRgbColors());
		mazebot.getColorIdSensor().setSamples(colorSensor.getColorId());
	}

	public SimEventDispatcher createEventDispatcher() { 
		return new SimEventDispatcher() {
			
			@Override
			public synchronized void onTogglePause() {
				pause = !pause;
			}
			
			@Override
			public synchronized void onSpeedIncrease() {
				speedScale *= 2;
			}
			
			@Override
			public synchronized void onSpeedDecrease() {
				speedScale /= 2;
			}
			
			@Override
			public synchronized double getSpeedFactor() {
				return speedScale;
			}

			@Override
			public boolean isPaused() {
				return pause;
			}
		};
	}
}
