package MazebotSim;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

import MazebotSim.Visualization.GuiMazeVisualization;

public class MazebotSimulation {
	
	private SimulatedMazebot mazebot;
	private MazeEnvironment environment;
	private SimEventLoop eventLoop;
	private double mazeWidth;
	private double mazeHeight;
	
	public MazebotSimulation(String pathToMazePng, double mazeWidth, double mazeHeight) {
		this.mazeWidth = mazeWidth;
		this.mazeHeight = mazeHeight;
		mazebot = new SimulatedMazebot(new RobotParameters());
		
		setRobotPosition(0.525, 0.175, 90);
		
		try {
			File imageFile = new File(pathToMazePng);
			BufferedImage img = ImageIO.read(imageFile);
			environment = new PngEnvironment(img, mazeWidth, mazeHeight);
		} catch(IOException ex ) {
			System.err.print("Can't load Maze File, please check file path!");
			System.err.print(ex.getMessage());
			System.exit(1);
		}
		eventLoop = new SimEventLoop(mazebot, environment, 0.001f);
		
		GlobalRobotConfAccessor.setRobot(mazebot);
	}

	
	public void setRobotPosition(double x, double y, double orientation) {
		RobotPosition pos = new RobotPosition();
		pos.orientation = Math.toRadians(orientation);
		pos.x = x - mazeWidth/2;
		pos.y = -y + mazeHeight/2;
		mazebot.setPos(pos);
	}
	
	public void setRobotPosition(RobotPosition pos) {
		pos.x = pos.x - mazeWidth/2;
		pos.y = -pos.y + mazeHeight/2;
		mazebot.setPos(pos);
	}
	
	public void activateGuiVisualization() {
		GuiMazeVisualization vis = new GuiMazeVisualization(
				mazeWidth,
				new StateAccessor());
		vis.setFramesPerSecond(25);
	}
	
	public RobotParameters getRobotParameters() {
		return mazebot.getRobotParameters();
	}
	
	public void updateRobotParameters(RobotParameters params) {
		mazebot.setRobotParameters(params);
	}
	
	public void scaleSpeed(float scale) {
		eventLoop.setSpeedScale(scale);
	}
		
	public void startSimulation() {
		eventLoop.start();
	}
	
	public void stopSimulation() {
		eventLoop.stop();
	}
	
	public StateAccessor getStateAccessor() {
		return new StateAccessor();
	}
	
	public class StateAccessor {
		public RobotPosition getPosition() {
			return mazebot.getPos();
		}
		
		public MazeEnvironment getEnvironment() {
			return environment;
		}
		
		public SimEventDispatcher getSimulationEventDispatcher() {
			return eventLoop.createEventDispatcher();
		}
		
		public ButtonEventDispatcher getButtonEventDispatcher() {
			return mazebot.getButtonEventDispatcher();
		}
	}
}
