package MazebotSim.Visualization;

import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

import lejos.hardware.lcd.LCD;

public class LCDPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextArea textArea;
	
	public LCDPanel() {
		textArea = new JTextArea();
		textArea.setColumns(LCD.DISPLAY_CHAR_WIDTH);
		textArea.setRows(LCD.DISPLAY_CHAR_DEPTH);
		textArea.setEditable(false);
		
		Font font = new Font(Font.MONOSPACED, Font.PLAIN, 20);
		textArea.setFont(font);
		
		add(textArea);
        
		TitledBorder titledBorder;
        titledBorder = BorderFactory.createTitledBorder("LCD Output");
        setBorder(titledBorder);
	}
	
	public void updateText() {
		byte[] bytes = LCD.getDisplay();
		String s = "";
		for (int y = 0; y < LCD.DISPLAY_CHAR_DEPTH; y++) {
			for(int x = 0; x < LCD.DISPLAY_CHAR_WIDTH; x++) {
				char c = (char) bytes[x*LCD.DISPLAY_CHAR_DEPTH + y];
				s += c;
			}
			s+= "\n";
		}
		textArea.setText(s);
	}

}
