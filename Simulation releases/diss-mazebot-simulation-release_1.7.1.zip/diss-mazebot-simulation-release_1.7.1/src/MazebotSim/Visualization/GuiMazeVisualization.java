package MazebotSim.Visualization;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import MazebotSim.*;
import MazebotSim.MazebotSimulation.StateAccessor;

public class GuiMazeVisualization {

	private double environmentWidth;
	
	private MazebotSimulation.StateAccessor stateAccessor;
	
	private int fps = 25;
	private MazePanel mazePanel; 
	private JFrame mainFrame;
	private LCDPanel lcdPanel;
	private ButtonPanel buttonPanel;
	
	public GuiMazeVisualization(double width, MazebotSimulation.StateAccessor stateAccessor) {
		this.stateAccessor = stateAccessor;
		environmentWidth = width;
	}
	
	public void showGUI() {
		SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
	}
	
	public void setFramesPerSecond(int fps) {
		this.fps = fps;
	}
	
	public void redraw(RobotPosition pos, MazeEnvironment env) {
		if (mazePanel != null) {
			mazePanel.setRobotPosition(pos);
			mazePanel.invalidate();
			mazePanel.validate();
			mazePanel.repaint();
		}
		if (lcdPanel != null) {
			lcdPanel.updateText();
		}
	}
	
	private void createAndShowGUI() {
        mainFrame = new JFrame("Mazebot Simulation");
        GridLayout layout = new GridLayout(1, 2);
        JPanel horizontalPanel = new JPanel(layout);
        mazePanel = new MazePanel(stateAccessor.getEnvironment(), environmentWidth);
        horizontalPanel.add(mazePanel);

        JPanel rightPanel = new JPanel(new GridLayout(2, 1));
        lcdPanel = new LCDPanel();
        buttonPanel = new ButtonPanel(stateAccessor.getButtonEventDispatcher());
        rightPanel.add(lcdPanel);
        rightPanel.add(buttonPanel);
        horizontalPanel.add(rightPanel);
                
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setVisible(true);
        mainFrame.setSize(new Dimension(800,600));
        mainFrame.getContentPane().add(horizontalPanel, BorderLayout.CENTER);
        
        SimulationToolbar toolbar = new SimulationToolbar(stateAccessor.getSimulationEventDispatcher());
        mainFrame.getContentPane().add(toolbar, BorderLayout.NORTH);
    }

	public void startVisualization() {
		showGUI();
		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				while(true) {
					try {
						TimeUnit.MILLISECONDS.sleep(1000/fps);
					} catch (InterruptedException ex) {
						System.err.print(ex);
					}
					RobotPosition pos = stateAccessor.getPosition();
					MazeEnvironment env = stateAccessor.getEnvironment();
					redraw(pos, env);
				}
			}
		});
		t.start();
	}
	
}
