package MazebotSim.Visualization;

import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;

import MazebotSim.MazeEnvironment;
import MazebotSim.RobotPosition;

public class MazePanel extends JPanel {
	
	private static final long serialVersionUID = 1L;
	
	private RobotPosition pos;
	private double environmentWidth;
	MazeGraphicsPrinter printer;
	
	public MazePanel(MazeEnvironment env, double environmentDimension) {
		environmentWidth = environmentDimension;
		printer = new MazeGraphicsPrinter(env, environmentWidth);
	}
	
	@Override
	public void paintComponent(Graphics g) {
		printer.setDimensions(getWidth(), getHeight());
		printer.paint(g, pos);
	}
	
	@Override
	public Dimension getPreferredSize() {
		return new Dimension(400, 400); 
	}
	
	public void setRobotPosition(RobotPosition pos) {
		this.pos = pos;
	}
}
