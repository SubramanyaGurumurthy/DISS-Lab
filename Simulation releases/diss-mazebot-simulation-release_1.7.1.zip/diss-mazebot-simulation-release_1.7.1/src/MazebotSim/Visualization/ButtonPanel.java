package MazebotSim.Visualization;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import MazebotSim.ButtonEventDispatcher;
import MazebotSim.ButtonEventDispatcher.BUTTON;

public class ButtonPanel extends JPanel implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private final int BTN_SIZE = 60;
	private final int PANEL_SIZE = 300;
	
	private JButton btnUp;
	private JButton btnDown;
	private JButton btnLeft;
	private JButton btnRight;
	private JButton btnOk;
	private JButton btnEscape;
	private Color defaultBgColor;
	
	private ButtonEventDispatcher evtDispatcher;
	
	public ButtonPanel(ButtonEventDispatcher eventDispatcher) {
		setLayout(null);
		setSize(300, 300);
		evtDispatcher = eventDispatcher;
		
		btnUp = new JButton("U");
		btnDown = new JButton("D");
		btnLeft = new JButton("L");
		btnRight = new JButton("R");
		btnOk = new JButton("OK");
		btnEscape = new JButton("ESC");
		
		add(btnUp);
		add(btnDown);
		add(btnLeft);
		add(btnRight);
		add(btnOk);
		add(btnEscape);
		defaultBgColor = btnUp.getBackground();
		
		btnUp.setBounds((PANEL_SIZE - BTN_SIZE)/2, BTN_SIZE, BTN_SIZE, BTN_SIZE);
		btnDown.setBounds((PANEL_SIZE - BTN_SIZE)/2, 3*BTN_SIZE, BTN_SIZE, BTN_SIZE);
		btnOk.setBounds((PANEL_SIZE - BTN_SIZE)/2, 2*BTN_SIZE, BTN_SIZE, BTN_SIZE);
		btnLeft.setBounds((PANEL_SIZE - BTN_SIZE)/2-BTN_SIZE, 2*BTN_SIZE, BTN_SIZE, BTN_SIZE);
		btnRight.setBounds((PANEL_SIZE - BTN_SIZE)/2+BTN_SIZE, 2*BTN_SIZE, BTN_SIZE, BTN_SIZE);
		btnEscape.setBounds(20, 20, BTN_SIZE, BTN_SIZE);
	
		btnUp.addActionListener(this);
		btnLeft.addActionListener(this);
		btnRight.addActionListener(this);
		btnDown.addActionListener(this);
		btnOk.addActionListener(this);
		btnEscape.addActionListener(this);
		
		TitledBorder titledBorder;
        titledBorder = BorderFactory.createTitledBorder("Buttons");
        setBorder(titledBorder);
	}
	
	private void updateAllButtonStates() {
		updateButtonState(BUTTON.UP, btnUp);
		updateButtonState(BUTTON.DOWN, btnDown);
		updateButtonState(BUTTON.LEFT, btnLeft);
		updateButtonState(BUTTON.RIGHT, btnRight);
		updateButtonState(BUTTON.OKAY, btnOk);
		updateButtonState(BUTTON.ESCAPE, btnEscape);
	}
	
	private void updateButtonState(BUTTON btn, JButton obj) {
		if (evtDispatcher.isButtonDown(btn)) {
			obj.setBackground(new Color(255,0,0));
		}
		else {
			obj.setBackground(defaultBgColor);
		}
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		BUTTON source;
		
		if (evt.getSource() == btnUp) {
			source = BUTTON.UP;
		}
		else if (evt.getSource() == btnDown) {
			source = BUTTON.DOWN;
		}
		else if (evt.getSource() == btnLeft) {
			source = BUTTON.LEFT;
		}
		else if (evt.getSource() == btnRight) {
			source = BUTTON.RIGHT;
		}
		else if (evt.getSource() == btnOk) {
			source = BUTTON.OKAY;
		}
		else if (evt.getSource() == btnEscape) {
			source = BUTTON.ESCAPE;
		}
		else {
			return;
		}
		
		toggleButtonState(source);
		updateAllButtonStates();		
	}
	
	private void toggleButtonState(BUTTON btn) {
		evtDispatcher.toggleButton(btn);
	}
}
