package MazebotSim.Visualization;

import MazebotSim.MazebotSimulation;
import MazebotSim.RobotPosition;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.imageio.stream.FileImageOutputStream;
import javax.imageio.stream.ImageOutputStream;

public class MazebotGifCreator {
	
	private int fps = 5;
	private double speedScale = 1;
	private int imgCount = 0;
	private List<BufferedImage> cachedImages;
	
	private double envWidth;
	private MazebotSimulation.StateAccessor stateAccessor;
	private MazeGraphicsPrinter mazePrinter;
	
	private Thread thread;
	private boolean isRecording = false;
	
	private ByteArrayOutputStream outStream;
	private ImageOutputStream imgOutStream;
	
	public MazebotGifCreator(double environmentWidth, MazebotSimulation.StateAccessor stateAccessor) {
		this.stateAccessor = stateAccessor;		
		this.envWidth = environmentWidth;
	}
	
	public void setFramesPerSecond(int fps) {
		this.fps = fps;
	}
	
	public void startRecording() throws Exception {
		
		if (isRecording) {
			throw new Exception("Recording is already running");
		}
		cachedImages = new LinkedList<BufferedImage>();
		mazePrinter = new MazeGraphicsPrinter(stateAccessor.getEnvironment(), envWidth);
		imgCount = 0;
		isRecording = true;
		thread = new Thread(new RecordingThread());
		thread.start();
	}
	
	private void storeImage() throws IOException {
		long now = System.currentTimeMillis();
		imgCount++;
		BufferedImage img = getImage(stateAccessor.getPosition());
		cachedImages.add(img);
		System.out.println("Storing image took " + (System.currentTimeMillis() - now) + "ms");
	}
	
	private BufferedImage getImage(RobotPosition pos) {
		BufferedImage imgBuffer = new BufferedImage(400, 400, BufferedImage.TYPE_INT_RGB);;
		mazePrinter.setDimensions(imgBuffer.getWidth(), imgBuffer.getHeight());
		mazePrinter.paint(imgBuffer.createGraphics(), pos);
		return imgBuffer;
	}
	
	public void setSpeedScale(double speedScale) {
		this.speedScale = speedScale;
	}
	
	synchronized public void stopRecording() throws IOException {
		isRecording = false;
		System.out.println("Wrote " + imgCount + " images");
		try {
			thread.join();
		}
		catch (InterruptedException ex) {
			System.err.println(ex);
		}
	}
	
	public byte[] getImageData() throws IOException {
		imgOutStream.flush();
		outStream.flush();
		return outStream.toByteArray();
	}
	
	synchronized public void writeImageToDisk(String filename) throws IOException {
		writeImageToDisk(new File(filename));
	}
	
	synchronized public void writeImageToDisk(File f) throws IOException {
		imgOutStream = new FileImageOutputStream(f);
		GifSequenceWriter gifSequenceWriter = null;
		for (BufferedImage img : cachedImages) {
			if (gifSequenceWriter == null) {
				gifSequenceWriter = new GifSequenceWriter(this.imgOutStream, img.getType(), (int)(1000/fps*speedScale), true);
			}
			gifSequenceWriter.writeToSequence(img);
		}
		gifSequenceWriter.close();	
		gifSequenceWriter = null;
	}
	
	private class RecordingThread implements Runnable {
		@Override
		public void run() {
			long waittimeMillis = (long)(1e3/fps/speedScale);
			long lastWakeup = System.currentTimeMillis();
			while(isRecording) {
				try {
					long wait = lastWakeup + waittimeMillis - System.currentTimeMillis();
					System.out.println("Wait " + wait + "ms");
					TimeUnit.MILLISECONDS.sleep(wait);
					System.out.println("Slept = " + (System.currentTimeMillis() - lastWakeup));
					lastWakeup = System.currentTimeMillis();
				} catch (InterruptedException ex) {
					System.err.print(ex);
				}
				try {
					storeImage();				
				}
				catch (IOException e) {
					System.err.println("Error creating image!");
				}
			}			
		}
	}
	
}
