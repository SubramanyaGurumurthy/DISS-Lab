package MazebotSim.Visualization;

import java.awt.Dimension;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JToolBar;

import MazebotSim.SimEventDispatcher;

public class SimulationToolbar extends JToolBar implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private SimEventDispatcher eventDispatcher;
	
	private JButton pause, speedUp, speedDown;
	private Label speedLabel;
	
	public SimulationToolbar(SimEventDispatcher eventDispatcher) {
		this.eventDispatcher = eventDispatcher;
		pause = new JButton("Pause");
		speedDown = new JButton("<<");
		speedUp = new JButton(">>");
		speedLabel = new Label();
		speedLabel.setMaximumSize(new Dimension(100,20));

		add(pause);
		addSeparator();
		add(speedDown);
		add(speedLabel);
		add(speedUp);
		
		speedDown.addActionListener(this);
		speedUp.addActionListener(this);
		pause.addActionListener(this);
		
		updateButtons();
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource() == pause) {
			eventDispatcher.onTogglePause();
		}
		else if (evt.getSource() == speedDown) {
			eventDispatcher.onSpeedDecrease();
		}
		else if (evt.getSource() == speedUp) {
			eventDispatcher.onSpeedIncrease();
		}
		updateButtons();
	}
	
	private void updateButtons() {
		speedLabel.setText("Speed: " + eventDispatcher.getSpeedFactor() + "x");
		if (eventDispatcher.isPaused()) {
			pause.setText("Play");
		}
		else {
			pause.setText("Pause");
		}
	}
	
	
}
