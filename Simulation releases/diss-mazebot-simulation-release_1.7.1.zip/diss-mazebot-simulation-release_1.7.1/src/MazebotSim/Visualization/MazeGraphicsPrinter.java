package MazebotSim.Visualization;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import MazebotSim.CubicleEnvironment;
import MazebotSim.MazeEnvironment;
import MazebotSim.PngEnvironment;
import MazebotSim.RobotPosition;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class MazeGraphicsPrinter {
	
	private MazeEnvironment env;
	private Graphics2D g;
	private BufferedImage robotImage;
	private RobotPosition pos;

	private int width;
	private int height;
	private double envWidth;
	
	public MazeGraphicsPrinter(MazeEnvironment mazeEnv, double environmentWidth) {
		this.env = mazeEnv;
		this.envWidth = environmentWidth;
		
		try {
			InputStream file = getClass().getResourceAsStream("robot.png");
			robotImage = ImageIO.read(file);
		} catch(IOException ex ) {
			System.err.print(ex.getMessage());
		}
	}
	
	public void setDimensions(int width, int height) {
		this.width = width;
		this.height = height;
	}
	
	public void paint(Graphics g, RobotPosition pos) {
		this.pos = pos;
		
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, width, height);
		g.setColor(Color.BLACK);
		this.g = (Graphics2D) g;
		
		AffineTransform old = this.g.getTransform();
		Dimension imgDim = getAspectCorrectedImageSize();
		g.translate(
				(int)imgDim.getWidth()/2, 
				(int) imgDim.getHeight()/2
		);
		
		if (pos != null) {
			drawRobot();
		}
		this.g.setTransform(old);
		
		if (env != null) {
			if (env instanceof CubicleEnvironment) {
				drawMazeCubicle((CubicleEnvironment)env);
			}
			else if (env instanceof PngEnvironment) {
				drawMazeImage((PngEnvironment)env);
			}
		}
	}
	
	private void drawRobot() {
		final double aspect = (double) robotImage.getWidth() / robotImage.getHeight();
		final int robotWidth = toPixelUnit(0.30);
		final int robotHeight = (int) ((double)robotWidth / aspect);
		
		AffineTransform old = g.getTransform();
		g.translate(toPixelUnit(pos.x), toPixelUnit(pos.y));
		g.rotate(-pos.getNormalizedOrientation());
		g.drawImage(robotImage, 
				-robotWidth/2, -robotHeight/2, robotWidth/2, robotHeight/2, 
				0, 0, robotImage.getWidth(), robotImage.getHeight(), 
				null);
		g.setTransform(old);
	}
	
	private void drawMazeCubicle(CubicleEnvironment env) {
		int x = toPixelUnit(-env.getWidth()/2);
		int y = toPixelUnit(-env.getHeight()/2);
		int width = toPixelUnit(env.getWidth());
		int height = toPixelUnit(env.getHeight());
		g.drawRect(x, y, width, height);
	}
	
	private void drawMazeImage(PngEnvironment env) {
		BufferedImage img = env.getMazeImage();
		// Scale acording to aspect ratio

		Dimension imgDim = getAspectCorrectedImageSize();
		g.drawImage(img, 0, 0, (int)imgDim.getWidth(), (int)imgDim.getHeight(), 
				0, 0, img.getWidth(), img.getHeight(), null);
	}
	
	private Dimension getAspectCorrectedImageSize() {
		int imgWidth, imgHeight;
		double aspect = env.getAspectRatio();
		int minimumSize = Math.min(width, height);
		if (aspect > 1) {
			imgWidth = minimumSize;
			imgHeight = (int) Math.round(minimumSize / aspect);
		}
		else {
			imgWidth = (int) Math.round(minimumSize * aspect);
			imgHeight = minimumSize;
		}
		return new Dimension(imgWidth, imgHeight);
	}
	
	private int toPixelUnit(double worldUnit) {
		Dimension imgDim = getAspectCorrectedImageSize();
		double conversion = imgDim.getWidth() / envWidth;
		return (int) Math.round(worldUnit * conversion);
	}

}
