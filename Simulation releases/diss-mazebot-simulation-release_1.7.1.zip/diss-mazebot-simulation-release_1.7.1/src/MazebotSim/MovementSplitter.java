package MazebotSim;

/**
 * This class provides Functionality to split an arbitrary movement
 * of the wheel motors into a translation and a turning component.
 * To do so, it uses Vector Projections 
 * v = 1/sqrt(2) * (1, 1) is the translation component
 * v = 1/sqrt(2) * (1, -1) is the turn component 
 */
public class MovementSplitter {

	private double dLeft;
	private double dRight;
	
	public MovementSplitter(double dLeft, double dRight) {
		this.dLeft = dLeft;
		this.dRight = dRight;
	}
	
	public double getTurnComponent() {
		double scalarProduct = dLeft - dRight;
		return scalarProduct / 2;
	}
	
	public double getTranslationComponent() {
		double scalarProduct = dLeft + dRight;
		return scalarProduct / 2;
	}
	
}
