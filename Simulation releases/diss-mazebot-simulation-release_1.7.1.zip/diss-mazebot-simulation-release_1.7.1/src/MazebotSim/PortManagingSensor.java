package MazebotSim;

import lejos.hardware.port.Port;
import lejos.hardware.port.PortException;
import lejos.hardware.port.UARTPort;
import lejos.hardware.sensor.BaseSensor;

public abstract class PortManagingSensor extends BaseSensor {
	
	private String portName; 
	
	public PortManagingSensor(Port port, String expectedPortname) {
		portName = port.getName();
		checkExpectedPortname(portName, expectedPortname);
		openPort();
	}
	
	public PortManagingSensor(UARTPort port, String expectedPortname) {
		portName = port.getName();
		checkExpectedPortname(portName, expectedPortname);
		openPort();
	}
	
	private void checkExpectedPortname(String actual, String expected) {
		if (actual != expected) {
			throw new PortException("Unexpected Sensor Port for this sensor");
		}
	}
	
	private void openPort() {
		PortManagement man = GlobalRobotConfAccessor.getRobot().getPortManagement();
		man.open(portName);
	}
	
	public void close() {
		PortManagement man = GlobalRobotConfAccessor.getRobot().getPortManagement();
		man.close(portName);
		super.close();
	}
}
