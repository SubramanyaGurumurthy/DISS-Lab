package MazebotSim;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

import lejos.hardware.Key;
import lejos.hardware.KeyListener;
import lejos.hardware.Keys;

public class ButtonEventDispatcher implements Keys {
	
	public enum BUTTON {
		UP,
		DOWN,
		LEFT,
		RIGHT,
		OKAY,
		ESCAPE
	};
	
	public Key downKey = new SimKey(Keys.ID_DOWN, "Down");
	public Key upKey = new SimKey(Keys.ID_UP, "Up");
	public Key leftKey = new SimKey(Keys.ID_LEFT, "Left");
	public Key rightKey = new SimKey(Keys.ID_RIGHT, "Right");
	public Key okKey = new SimKey(Keys.ID_ENTER, "Enter");
	public Key escKey = new SimKey(Keys.ID_ESCAPE, "Escape");
	
	private Key[] allKeys = {
			downKey, upKey, leftKey, rightKey, okKey, escKey
	};
	
	private List<Event> events = new ArrayList<Event>();
	
	private class Event {
		public Key key;
		public int event;
	}
	
	public ButtonEventDispatcher() {		
		KeyListener listener = new KeyListener() {
			@Override
			public void keyReleased(Key key) {
				Event e = new Event();
				e.key = key;
				e.event = Key.KEY_RELEASED;
				events.add(e);
			}
			
			@Override
			public void keyPressed(Key key) {
				Event e = new Event();
				e.key = key;
				e.event = Key.KEY_PRESSED;
				events.add(e);
			}
		};
		downKey.addKeyListener(listener);
		upKey.addKeyListener(listener);
		leftKey.addKeyListener(listener);
		rightKey.addKeyListener(listener);
		okKey.addKeyListener(listener);
		escKey.addKeyListener(listener);
	}
	
	public boolean isButtonDown(BUTTON btn) {
		return enumToKey(btn).isDown();
	}
	
	public boolean isButtonUp(BUTTON btn) {
		return enumToKey(btn).isUp();
	}
	
	public void setButtonPressed(BUTTON btn) {
		enumToKey(btn).simulateEvent(Key.KEY_PRESSED);
	}
	
	public void setButtonReleased(BUTTON btn) {
		enumToKey(btn).simulateEvent(Key.KEY_RELEASED);	
	}
	
	public void toggleButton(BUTTON btn) {
		if (isButtonUp(btn)) {
			setButtonPressed(btn);
		}
		else {
			setButtonReleased(btn);
		}
	}

	@Override
	public void discardEvents() {
		events.clear();
	}

	@Override
	public int getButtons() {
		int bits = 0;
		for (Key k : allKeys) {
			if (k.isDown()) {
				bits |= k.getId();
			}
		}
		return bits;
	}

	@Override
	public int getKeyClickLength() {
		return 0;
	}

	@Override
	public int getKeyClickTone(int arg0) {
		return 0;
	}

	@Override
	public int getKeyClickVolume() {
		return 0;
	}

	@Override
	public int readButtons() {
		return getButtons();
	}

	@Override
	public void setKeyClickLength(int arg0) {
	
	}

	@Override
	public void setKeyClickTone(int arg0, int arg1) {
	}

	@Override
	public void setKeyClickVolume(int arg0) {
	}

	@Override
	public synchronized int waitForAnyEvent() {
		return waitForAnyEvent(Integer.MAX_VALUE);
	}

	@Override
	public synchronized int waitForAnyEvent(int timeout) {
		discardEvents();
		long startTime = System.currentTimeMillis();
		long elapsed = 0;
		
		do {
			try {
				wait(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			elapsed = System.currentTimeMillis() - startTime;
		} while (events.size() == 0 && elapsed < timeout);
		return produceBitmaskFromEvents();
	}

	@Override
	public int waitForAnyPress() {
		return waitForAnyPress(Integer.MAX_VALUE);
	}

	@Override
	public synchronized int waitForAnyPress(int timeout) {
		discardEvents();
		long startTime = System.currentTimeMillis();
		long elapsed = 0;
		boolean hasPressEvents = false; 
		
		do {
			try {
				wait(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			elapsed = System.currentTimeMillis() - startTime;
			for (Event e : events) {
				if (e.event == Key.KEY_PRESSED) {
					hasPressEvents = true;
				}
			}
		} while (! hasPressEvents && elapsed < timeout);
		return produceBitmaskFromEvents() & 0xFF;
	}
	
	private int produceBitmaskFromEvents() {
		int result = 0;
		for (Event e: events) {
			if (e.event == Key.KEY_PRESSED) {
				result |= e.key.getId();
			}
			if (e.event == Key.KEY_RELEASED) {
				result |= (e.key.getId() << 8);
			}
		}
		return result;
	}
	
	private Key enumToKey(BUTTON b) {
		switch(b) {
		case DOWN:
			return downKey;
		case UP:
			return upKey;
		case LEFT:
			return leftKey;
		case RIGHT: 
			return rightKey;
		case OKAY:
			return okKey;
		case ESCAPE:
			return escKey;
		default:
			throw new InvalidParameterException("Unkown Key");
		}
	}
}
