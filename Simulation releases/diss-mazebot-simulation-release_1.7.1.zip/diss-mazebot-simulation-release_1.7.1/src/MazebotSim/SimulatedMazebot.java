package MazebotSim;

import lejos.hardware.Button;

public class SimulatedMazebot {
	
	private RobotParameters params;
	
	private PortManagement portManager = new PortManagement();
	private SimRegulatedMotor motorLeft = new SimRegulatedMotor();
	private SimRegulatedMotor motorRight = new SimRegulatedMotor();
	private SimSampleProvider distanceSensor = new SimSampleProvider(1, "Distance");
	private SimSampleProvider gyroOrientation = new SimSampleProvider(1, "Angle");
	private SimSampleProvider gyroRate = new SimSampleProvider(1, "Rate");
	private SimSampleProvider rgbColorSensor = new SimSampleProvider(3, "RGB");
	private SimSampleProvider colorIdSensor = new SimSampleProvider(1, "ColorID");
	
	private ButtonEventDispatcher buttonEvents = new ButtonEventDispatcher();
	
	private RobotPosition pos = new RobotPosition();
	
	public SimulatedMazebot(RobotParameters params) {
		setupStaticButtonClass();
		setRobotParameters(params);
	}
	
	public void setRobotParameters(RobotParameters params) {
		this.params = params;
	}
	
	public RobotPosition getPos() {
		return pos;
	}
	
	public RobotParameters getRobotParameters() {
		return this.params;
	}
	
	public void setPos(RobotPosition pos) {
		this.pos = pos;
	}
	
	public SimRegulatedMotor getMotorLeft() {
		return motorLeft;
	}
	
	public SimRegulatedMotor getMotorRight() {
		return motorRight;
	}

	public SimSampleProvider getDistanceSensor() {
		return distanceSensor;
	}

	public SimSampleProvider getGyroOrientation() {
		return gyroOrientation;
	}
	
	public SimSampleProvider getRGBColorSensor() {
		return rgbColorSensor;
	}
	
	public SimSampleProvider getColorIdSensor() {
		return colorIdSensor;
	}
	
	public SimSampleProvider getGyroRate() {
		return gyroRate;
	}
	
	public ButtonEventDispatcher getButtonEventDispatcher() {
		return buttonEvents;
	}
	
	public PortManagement getPortManagement() {
		return portManager;
	}
	
	public void updatePosition(RobotPosition pos) {
		this.pos = pos;
	}
	
	private void setupStaticButtonClass() {
		Button.keys = buttonEvents;
		Button.UP = buttonEvents.upKey;
		Button.DOWN = buttonEvents.downKey;
		Button.LEFT = buttonEvents.leftKey;
		Button.RIGHT = buttonEvents.rightKey;
		Button.ENTER = buttonEvents.okKey;
		Button.ESCAPE = buttonEvents.escKey;
	}
	
	
}
