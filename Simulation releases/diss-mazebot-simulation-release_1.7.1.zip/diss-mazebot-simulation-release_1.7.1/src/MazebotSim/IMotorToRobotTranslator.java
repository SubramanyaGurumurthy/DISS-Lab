package MazebotSim;

public interface IMotorToRobotTranslator {

	public RobotPosition setMotorMovements(double[] movements, RobotPosition currentPosition);
	
}
