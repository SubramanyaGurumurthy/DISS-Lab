package MazebotSim.Audio;

import java.io.File;

import javax.sound.sampled.*;

import lejos.hardware.Audio;
import lejos.hardware.Sounds;
import lejos.utility.Delay;

public class AudioGenerator implements Audio {
	
	private int volume = 50;
	
    public void tone(int hz, int msecs) 
    throws LineUnavailableException 
    {
        tone(hz, msecs, 1.0);
    }

    private void tone(int frequency, int duration, double vol)
    {
        byte[] buf = new byte[1];
        float sampleRate = 3* frequency;
        int numSamples = (int) Math.round((double)duration/1000*sampleRate);
        try {
        	AudioFormat af = new AudioFormat(sampleRate,8,1,true,false);     
        	SourceDataLine sdl = AudioSystem.getSourceDataLine(af);
        	sdl.open(af);
        	sdl.start();
        	for (int i=0; i < numSamples; i++) {
        		double angle = i / (sampleRate / frequency) * 2.0 * Math.PI;
        		buf[0] = (byte)(Math.sin(angle) * 127.0 * vol);
        		sdl.write(buf,0,1);
        	}
        	sdl.drain();
        	sdl.stop();
        	sdl.close();
        } catch (LineUnavailableException ex) {
        	System.err.println("Audio Format not supported");
        	System.out.println("Just imagine a BEEEEP ;)");
        }
    }

	@Override
	public int getVolume() {
		return volume;
	}

	@Override
	public void loadSettings() {
		
	}

	@Override
	public void playNote(int[] intrument, int freq, int duration) {
		playTone(freq, duration);
	}

	@Override
	public int playSample(File arg0) {
		System.err.print("PlaySample is unimplemented in simulation");
		return 0;
	}

	@Override
	public int playSample(File arg0, int arg1) {
		System.err.print("PlaySample is unimplemented in simulation");
		return 0;
	}

	@Override
	public int playSample(byte[] arg0, int arg1, int arg2, int arg3, int arg4) {
		System.err.print("PlaySample is unimplemented in simulation");
		return 0;
	}

	@Override
	public void playTone(int freq, int duration) {
		playTone(freq, duration, this.volume);
	}

	@Override
	public void playTone(int freq, int duration, int volume) {
		tone(freq, duration, (double) volume/100);		
	}

	@Override
	public void setVolume(int volume) {
		if (volume >= 0 && volume <= 100) {
			this.volume = volume;
		}
	}

	@Override
	public void systemSound(int code) {
		switch (code) {
		case Sounds.BEEP:
			playTone(440, 200);
			break;
		case Sounds.DOUBLE_BEEP:
			playTone(440, 200);
			Delay.msDelay(500);
			playTone(440, 200);
			break;
		case Sounds.BUZZ:
			playTone(220, 1000);
			break;
		default:
			System.err.println("Some system sounds not implemented in simulation");
		}
	}
}
