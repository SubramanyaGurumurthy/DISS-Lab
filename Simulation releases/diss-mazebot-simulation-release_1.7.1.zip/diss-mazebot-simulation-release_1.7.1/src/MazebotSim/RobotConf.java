package MazebotSim;

import lejos.robotics.RegulatedMotor;
import lejos.robotics.SampleProvider;

public interface RobotConf {
	
	public SampleProvider getRGBSampleProvider();
	
	public SampleProvider getColorIdSampleProvider();
	
	public SampleProvider getGyroAngleSampleProvider();
	
	public SampleProvider getDistanceSampleProvider();
	
	public RegulatedMotor getLeftWheelMotor();
	
	public RegulatedMotor getRightWheelMotor();

}
