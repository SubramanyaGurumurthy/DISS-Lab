package MazebotSim;

public class SimTachometer {
	private final double INERTIA_PARAM = 0.02;
	private final double STOP_THRESHOLD = 1e-6;
	
	private final double tolerance = Math.toRadians(1);
	private double speed = 0;
	private double setSpeed = 0; 
	private double angle = 0;
	
	private boolean hasGoal;
	private double goal = 0;
	
	public double performSimulationStep(double deltaTime) {
		speed = INERTIA_PARAM * setSpeed + ( 1 - INERTIA_PARAM) * speed;
		if (Math.abs(speed) <= STOP_THRESHOLD) {
			speed = 0;
		}
		
		double dTurn = deltaTime * speed;
		angle += dTurn;
		
		if (hasGoal) {
			if (hasReachedGoal()) {
				hasGoal = false;
				setSpeed = 0;
			}
			else {
				double delta = goal - angle;
				if (delta * speed < 0) {
					setSpeed = -speed/2;
				}
			}
		}
		return dTurn;
	}
	
	public boolean hasReachedGoal() {
		if (hasGoal) {
			double delta = Math.abs(angle - goal);
			return delta <= tolerance;
		}
		return false;
	}
	
	public void setSpeed(double speed) {
		this.setSpeed = speed;
	}
	
	public void setGoal(double goal) {
		this.goal = goal;
		this.hasGoal = true;
	}
	
	public void setGoalRelative(double goal) {
		setGoal(angle + goal);
	}
	
	public void removeGoal() {
		this.hasGoal = false;
	}
	
	public boolean tachoHasGoal() {
		return this.hasGoal;
	}
	
	public double getSpeed() {
		return speed;
	}
	
	public double getGoal() {
		return goal;
	}
	
	public void resetTachoCount() {
		angle = 0;
	}
	
	public double getTachoCount() {
		return angle;
	}
	
}
