package lejos.hardware.lcd;

public class LCD {
	
	public static final int SCREEN_WIDTH = 178;
    public static final int SCREEN_HEIGHT = 128;
    public static final int NOOF_CHARS = 96;
    public static final int FONT_WIDTH = 10;
    public static final int FONT_HEIGHT = 16;
    public static final int CELL_WIDTH = FONT_WIDTH;
    public static final int CELL_HEIGHT = FONT_HEIGHT;
    public static final int DISPLAY_CHAR_WIDTH = SCREEN_WIDTH / CELL_WIDTH;
    public static final int DISPLAY_CHAR_DEPTH = SCREEN_HEIGHT / CELL_HEIGHT;
    
    /**
     * Common raster operations for use with bitBlt
     */
    public static final int ROP_CLEAR = 0x00000000;
    public static final int ROP_AND = 0xff000000;
    public static final int ROP_ANDREVERSE = 0xff00ff00;
    public static final int ROP_COPY = 0x0000ff00;
    public static final int ROP_ANDINVERTED = 0xffff0000;
    public static final int ROP_NOOP = 0x00ff0000;
    public static final int ROP_XOR = 0x00ffff00;
    public static final int ROP_OR = 0xffffff00;
    public static final int ROP_NOR = 0xffffffff;
    public static final int ROP_EQUIV = 0x00ffffff;
    public static final int ROP_INVERT = 0x00ff00ff;
    public static final int ROP_ORREVERSE = 0xffff00ff;
    public static final int ROP_COPYINVERTED = 0x0000ffff;
    public static final int ROP_ORINVERTED = 0xff00ffff;
    public static final int ROP_NAND = 0xff0000ff;
    public static final int ROP_SET = 0x000000ff;
	
	private static char[][] matrix = new char[DISPLAY_CHAR_WIDTH][DISPLAY_CHAR_DEPTH];
	
	public static void bitBlt(byte[] src, int sw, int sh, int sx, int sy, int dx, int dy, int w, int h, int rop) {}

    public static void drawChar(char c, int x, int y) {
    	if (coordinatesValid(x, y)) {
    		matrix[x][y] = c;
    	}
    }

    public static void clearDisplay() {
    	for (int x = 0; x < DISPLAY_CHAR_WIDTH; x++) {
    		for (int y = 0; y < DISPLAY_CHAR_DEPTH; y++) {
    			matrix[x][y] = ' ';
    		}
    	}
    }

    public static void drawString(String str, int x, int y, boolean inverted) {
    	for (int i = 0; i < str.length(); i++) {
    		if (coordinatesValid(x + i, y)) {
    			matrix[x+i][y] = str.charAt(i);
    		}    		
    	}
    }

    public static void drawString(String str, int x, int y) {
    	drawString(str, x, y, false);
    }

    public static void drawInt(int i, int x, int y) {
    	String s = Integer.toString(i);
    	drawString(s, x, y);
    }

    public static void drawInt(int i, int places, int x, int y) {
    	String s = Integer.toString(i);
    	while(s.length() < places) {
    		s = " " + s;
    	}
    	drawString(s, x, y);
    }

    public static void asyncRefresh() {}

    public static long getRefreshCompleteTime() {
    	return 0;
    }

    public static void asyncRefreshWait() {}

    public static void refresh() {}

    public static void clear() {
    	clearDisplay();
    }
    
    public static byte[] getDisplay()
    {
    	byte[] result = new byte[DISPLAY_CHAR_DEPTH*DISPLAY_CHAR_WIDTH];
    	for (int i = 0; i < DISPLAY_CHAR_WIDTH; i++) {
    		for (int j = 0; j < DISPLAY_CHAR_DEPTH; j++) {
    			result[i*DISPLAY_CHAR_DEPTH + j] = (byte) matrix[i][j];
    		}
    	}
    	return result;
    }

    public static byte[] getSystemFont()
    {
    	return new byte[0];
    }

   
    public static int setAutoRefreshPeriod(int period)
    { 
    	return 0;
    }

    public static void setAutoRefresh(boolean on)
    {}
    
    public static void setPixel(int x, int y, int color)
    {}

    public static int getPixel(int x, int y) {
        return 0;
    }

    public static void bitBlt(byte[] src, int sw, int sh, int sx, int sy, byte dst[], int dw, int dh, int dx, int dy, int w, int h, int rop)
    {    }     
    
    public static void scroll()
    {}
    
    public static void clear(int x, int y, int n) { 
    	for (int i = x; i < x+n; i++) {
    		if (coordinatesValid(i, y)) {
    			matrix[i][y] = ' ';
    		}
    	}
    }
    
    public static void clear(int y) {
    	clear(0, y, DISPLAY_CHAR_WIDTH);
    }

    public static void setContrast(int contrast)
    {
        // Not implemented
    }
    
    public static byte[] getHWDisplay() {
    	return new byte[0];
    }
    
    private static boolean coordinatesValid(int x, int y) {
    	return x < DISPLAY_CHAR_WIDTH && y < DISPLAY_CHAR_DEPTH
    		&& x >= 0 && y >= 0;
    }
}
