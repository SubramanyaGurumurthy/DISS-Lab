package lejos.hardware.sensor;

import MazebotSim.GlobalRobotConfAccessor;
import MazebotSim.PortManagingSensor;
import MazebotSim.SimSampleProvider;
import MazebotSim.SimulatedMazebot;
import lejos.hardware.port.Port;
import lejos.hardware.port.UARTPort;

public class EV3ColorSensor extends PortManagingSensor {
	
	private SimulatedMazebot mazebot;
	
	public EV3ColorSensor(UARTPort port) {
		super(port, "S1");
		init();
	}
	
	public EV3ColorSensor(Port port) {
		super(port, "S1");
		init();
	}
	
	private void init() {
		mazebot = GlobalRobotConfAccessor.getRobot();
		setModes(new SensorMode[] {
			mazebot.getColorIdSensor(),
			new SimSampleProvider(1, "Red"),
			mazebot.getRGBColorSensor(),
			new SimSampleProvider(1, "Ambient")
		});
	}
		
	public int getColorID() {
		float[] samples = new float[1];
		mazebot.getColorIdSensor().fetchSample(samples, 0);
		return (int) samples[0];
	}
	
	public boolean isFloodlightOn() {
		return true;
	}
	
	public int getFloodlight() {
		return 0;
	}
	
	public boolean setFloodlight(int color) {
		return false;
	}
	
	public SensorMode getColorIDMode() {
		return mazebot.getColorIdSensor();
	}
	
	public SensorMode getRGBMode()
    {
        return mazebot.getRGBColorSensor();
    }
	
	public SensorMode getRedMode()
    {
        System.err.println("Red Mode not available in Simulation");
        return null;
    }
	
	public SensorMode getAmbientMode()
    {
		System.err.println("Ambient Mode not available in Simulation");
        return null;
    }
	
	public void setFloodlight(boolean floodlight) {
		
	}
	
}
