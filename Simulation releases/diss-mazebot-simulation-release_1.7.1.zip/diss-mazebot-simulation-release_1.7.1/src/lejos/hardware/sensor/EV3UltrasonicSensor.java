package lejos.hardware.sensor;

import MazebotSim.GlobalRobotConfAccessor;
import MazebotSim.PortManagingSensor;
import MazebotSim.SimSampleProvider;
import MazebotSim.SimulatedMazebot;
import lejos.hardware.port.Port;
import lejos.hardware.port.UARTPort;
import lejos.robotics.SampleProvider;

public class EV3UltrasonicSensor extends PortManagingSensor {

	private SimulatedMazebot mazebot;
	private boolean enabled = true;
	
	public EV3UltrasonicSensor(Port port) {
		super(port, "S4");
		init();
	}
	
	public EV3UltrasonicSensor(UARTPort port) {
		super(port, "S4");
		init();
	}
	
	protected void init() {
		mazebot = GlobalRobotConfAccessor.getRobot();
		setModes( new SensorMode[] {
				mazebot.getDistanceSensor(),
				new SimSampleProvider(1, "Listen")
		});
	}
	
	public SampleProvider getListenMode() {
		System.err.println("Listen Mode not implemented in Simulation");
		return getMode("Listen");
	}
	
	public SampleProvider getDistanceMode() {
		return getMode("Distance");
	}
	
	public void enable() {
		enabled = true;
	}
	
	public void disable() {
		enabled = false;
	}
	
	public boolean isEnabled() {
		return enabled;
	}
}
