package lejos.hardware.sensor;

import MazebotSim.GlobalRobotConfAccessor;
import MazebotSim.PortManagingSensor;
import MazebotSim.SimulatedMazebot;
import lejos.hardware.port.Port;
import lejos.hardware.port.UARTPort;
import lejos.robotics.SampleProvider;

public class EV3GyroSensor extends PortManagingSensor {

	private AngleModeWithOffset angleMode;
	
	public EV3GyroSensor(Port port) {
		super(port, "S3");
		init();
	}

	public EV3GyroSensor(UARTPort port) {
		super(port, "S3");
		init();
	}

	private void init() {
		SimulatedMazebot mazebot = GlobalRobotConfAccessor.getRobot();
		angleMode = new AngleModeWithOffset(mazebot.getGyroOrientation());
		setModes(new SensorMode[] {
				mazebot.getGyroRate(),
				angleMode,
				new RateAndAngleMode(mazebot.getGyroRate(), angleMode)
		});
		reset();
	}

	public SampleProvider getAngleMode() {
		return getMode(1);
	}

	public SampleProvider getRateMode() {
		return getMode(0);
	}

	public SampleProvider getAngleAndRateMode() {
		return getMode(2);
	}

	public void reset() {
		double globalOrientation = GlobalRobotConfAccessor.getRobot().getPos().orientation;
		int rounded = (int) Math.round(Math.toDegrees(globalOrientation));
		angleMode.setValueOffset(rounded);
	}
	
	private class RateAndAngleMode implements SensorMode {

		SensorMode rateMode;
		SensorMode angleMode;
		
		public RateAndAngleMode(SensorMode rateMode, SensorMode angleMode) {
			this.rateMode = rateMode;
			this.angleMode = angleMode;
		}

		@Override
		public void fetchSample(float[] samples, int offset) {
			rateMode.fetchSample(samples, 0);
			angleMode.fetchSample(samples, 1);			
		}

		@Override
		public int sampleSize() {
			return 2;
		}

		@Override
		public String getName() {
			return "Angle and Rate";
		}
	}
	
	private class AngleModeWithOffset implements SensorMode {
		
		private float valueOffset = 0;
		private SensorMode sourceMode; 
		
		public AngleModeWithOffset(SensorMode sourceMode) {
			this.sourceMode = sourceMode;
		}
		
		@Override
		public void fetchSample(float[] samples, int offset) {
			sourceMode.fetchSample(samples, offset);
			samples[0] -= valueOffset;
		}

		@Override
		public int sampleSize() {
			return sourceMode.sampleSize();
		}

		@Override
		public String getName() {
			return sourceMode.getName();
		}
		
		public void setValueOffset(float offset) {
			this.valueOffset = offset;
		}
		
	}
}
