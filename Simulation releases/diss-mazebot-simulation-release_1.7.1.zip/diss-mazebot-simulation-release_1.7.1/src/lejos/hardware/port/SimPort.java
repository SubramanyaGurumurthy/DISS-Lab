package lejos.hardware.port;

public class SimPort implements Port {

	private String name;
	
	public SimPort(String name) {
		this.name = name;
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public <T extends IOPort> T open(Class<T> portclass) {
		return null;
	}
	
}
