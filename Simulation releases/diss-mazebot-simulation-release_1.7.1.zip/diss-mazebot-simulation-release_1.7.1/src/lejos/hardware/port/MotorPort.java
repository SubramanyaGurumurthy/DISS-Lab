package lejos.hardware.port;

public interface MotorPort {

	public static final Port A = new SimPort("A");

	public static final Port B = new SimPort("B");
	
    public static final Port C = new SimPort("C");
    
    public static final Port D = new SimPort("D");

}
