package lejos.hardware.port;

public class SensorPort {
	public static final Port S1 = new SimPort("S1");
    public static final Port S2 = new SimPort("S2");
    public static final Port S3 = new SimPort("S3");
    public static final Port S4 = new SimPort("S4");
}
