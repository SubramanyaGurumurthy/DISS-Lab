package lejos.hardware.motor;

import MazebotSim.GlobalRobotConfAccessor;
import lejos.hardware.port.Port;
import lejos.hardware.port.PortException;
import lejos.hardware.port.TachoMotorPort;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.RegulatedMotorListener;

public class EV3LargeRegulatedMotor implements RegulatedMotor {

	private String portName;
	private RegulatedMotor motor;
	
	public EV3LargeRegulatedMotor(TachoMotorPort port) {
		init(port.getName());
	}
	
	public EV3LargeRegulatedMotor(Port port) {
		init(port.getName());
	}
	
	private void init(String portName) {
		this.portName = portName;
		GlobalRobotConfAccessor.getRobot().getPortManagement().open(portName);
		switch (portName) {
		case "B":
			motor = GlobalRobotConfAccessor.getRobot().getMotorLeft();
			break;
		case "C":
			motor = GlobalRobotConfAccessor.getRobot().getMotorRight();
			break;
		default: 
			throw new PortException("Port " + portName + " is unconnected on Robot");
		}		
	}

	@Override
	public void forward() {
		motor.forward();		
	}

	@Override
	public void backward() {
		motor.backward();
	}

	@Override
	public void stop() {
		motor.stop();
	}

	@Override
	public void flt() {
		motor.flt();
	}

	@Override
	public boolean isMoving() {
		return motor.isMoving();
	}

	@Override
	public int getRotationSpeed() {
		return motor.getRotationSpeed();
	}

	@Override
	public int getTachoCount() {
		return motor.getTachoCount();
	}

	@Override
	public void resetTachoCount() {
		motor.resetTachoCount();
	}

	@Override
	public void addListener(RegulatedMotorListener listener) {
		motor.addListener(listener);
	}

	@Override
	public RegulatedMotorListener removeListener() {
		return motor.removeListener();
	}

	@Override
	public void stop(boolean immediateReturn) {
		motor.stop(immediateReturn);
	}

	@Override
	public void flt(boolean immediateReturn) {
		motor.flt(immediateReturn);
	}

	@Override
	public void waitComplete() {
		motor.waitComplete();
	}

	@Override
	public void rotate(int angle, boolean immediateReturn) {
		motor.rotate(angle, immediateReturn);
	}

	@Override
	public void rotate(int angle) {
		motor.rotate(angle);
	}

	@Override
	public void rotateTo(int limitAngle) {
		motor.rotateTo(limitAngle);
	}

	@Override
	public void rotateTo(int limitAngle, boolean immediateReturn) {
		motor.rotateTo(limitAngle, immediateReturn);
	}

	@Override
	public int getLimitAngle() {
		return motor.getLimitAngle();
	}

	@Override
	public void setSpeed(int speed) {
		motor.setSpeed(speed);
	}
	
	public void setSpeed(float speed) {
		motor.setSpeed((int)speed);
	}

	@Override
	public int getSpeed() {
		return motor.getSpeed();
	}

	@Override
	public float getMaxSpeed() {
		return motor.getMaxSpeed();
	}

	@Override
	public boolean isStalled() {
		return motor.isStalled();
	}

	@Override
	public void setStallThreshold(int error, int time) {
		motor.setStallThreshold(error, time);
	}

	@Override
	public void setAcceleration(int acceleration) {
		motor.setAcceleration(acceleration);
	}

	@Override
	public void synchronizeWith(RegulatedMotor[] syncList) {
		motor.synchronizeWith(syncList);
	}

	@Override
	public void startSynchronization() {
		motor.startSynchronization();
	}

	@Override
	public void endSynchronization() {
		motor.endSynchronization();
	}

	@Override
	public void close() {
		motor.close();
		GlobalRobotConfAccessor.getRobot().getPortManagement().close(portName);
	}
}
