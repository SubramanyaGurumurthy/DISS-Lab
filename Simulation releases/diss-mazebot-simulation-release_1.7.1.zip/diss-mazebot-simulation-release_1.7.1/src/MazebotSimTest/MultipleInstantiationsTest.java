package MazebotSimTest;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import MazebotSim.MazebotSimulation;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.PortException;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.robotics.RegulatedMotor;

public class MultipleInstantiationsTest {
	
	MazebotSimulation sim;
	
	@Before
	public void setup() {
		sim = new MazebotSimulation("", 10, 10);
	}
	
	@Test
	public void ShouldThrowExceptionIfMotorsAreInstantiatedMultipleTimes() {
		RegulatedMotor first = new EV3LargeRegulatedMotor(MotorPort.B);
		try {
			RegulatedMotor second = new EV3LargeRegulatedMotor(MotorPort.B);
		}
		catch (PortException exception) {
			first.close();
			return;
		}
		fail();
	}
	
	@Test 
	public void ShouldWorkIfMotorsWithDifferentPortsAreInitiated() {
		RegulatedMotor first = new EV3LargeRegulatedMotor(MotorPort.C);
		try {
			RegulatedMotor second = new EV3LargeRegulatedMotor(MotorPort.B);
			second.close();
		}
		catch (PortException exception) {
			fail();
		}
		first.close();
	}
	
	@Test 
	public void ShouldFailIfPortIsWrongForSensor() {
		EV3ColorSensor color;
		try {
			color = new EV3ColorSensor(SensorPort.S2);
		}
		catch (PortException e) {
			return;
		}
		color.close();
		fail();
	}
	
	@Test 
	public void ShouldFailIfSensorInitsTwice() {
		EV3ColorSensor color1 = new EV3ColorSensor(SensorPort.S1);
		try {
			EV3ColorSensor color2 = new EV3ColorSensor(SensorPort.S2);
			color2.close();
		}
		catch (PortException e) {
			return;
		}
		finally {
			color1.close();		
		}
		fail();
	}
}
