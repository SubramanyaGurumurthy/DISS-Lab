package MazebotSimTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import MazebotSim.CubicleEnvironment;
import MazebotSim.RobotParameters;
import MazebotSim.SimEventLoop;
import MazebotSim.SimulatedMazebot;

public class SimEventLoopTest {

	@Test
	public void TestDrivingStraight() {
		SimulatedMazebot mazebot = new SimulatedMazebot(new RobotParameters());
		SimEventLoop eventLoop = new SimEventLoop(mazebot, new CubicleEnvironment(1,1), (float)1e-3);
		
		mazebot.getMotorLeft().setSpeed(100);
		mazebot.getMotorLeft().forward();
		mazebot.getMotorRight().setSpeed(100);
		mazebot.getMotorRight().forward();
		
		for (int i = 0; i < 100; i++) {
			eventLoop.performSimulationStep();
		}
		
		assertEquals(-0.0015, mazebot.getPos().x, 0.0001);
		assertEquals(0, mazebot.getPos().y, 0.0001);
		assertEquals(0, mazebot.getPos().orientation, 0.0001);
	}
	
	public void TestTurning() {
		SimulatedMazebot mazebot = new SimulatedMazebot(new RobotParameters());
		SimEventLoop eventLoop = new SimEventLoop(mazebot, new CubicleEnvironment(1,1), (float)1e-3);
		
		mazebot.getMotorLeft().setSpeed(100);
		mazebot.getMotorLeft().forward();
		mazebot.getMotorRight().setSpeed(100);
		mazebot.getMotorRight().backward();
		
		for (int i = 0; i < 100; i++) {
			eventLoop.performSimulationStep();
		}
		
		assertEquals(0, mazebot.getPos().x, 0.0001);
		assertEquals(0, mazebot.getPos().y, 0.0001);
		assertEquals(0.0857, mazebot.getPos().orientation, 0.0001);
	}
}
