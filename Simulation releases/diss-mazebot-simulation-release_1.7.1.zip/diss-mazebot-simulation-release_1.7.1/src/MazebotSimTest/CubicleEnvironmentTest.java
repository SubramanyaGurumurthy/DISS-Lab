package MazebotSimTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import MazebotSim.CubicleEnvironment;
import MazebotSim.RobotPosition;

public class CubicleEnvironmentTest {

	@Test
	public void DistanceMeasurementTest() {
		CubicleEnvironment env = new CubicleEnvironment(10, 10);
		RobotPosition pos = new RobotPosition();
		
		double dist = env.getDistanceMeasurement(pos);
		assertEquals(5, dist, 1e-6);
		
		pos.turn(Math.PI/4);
		pos.driveStraight(1);
		double expected = Math.sqrt(2*25) - 1;
		dist = env.getDistanceMeasurement(pos);
		assertEquals(expected, dist, 1e-6);
		
		pos.driveStraight(-1);
		pos.turn(-Math.PI/2);
		pos.driveStraight(1);
		expected = Math.sqrt(2*25) - 1;
		dist = env.getDistanceMeasurement(pos);
		assertEquals(expected, dist, 1e-6);
	}
}
