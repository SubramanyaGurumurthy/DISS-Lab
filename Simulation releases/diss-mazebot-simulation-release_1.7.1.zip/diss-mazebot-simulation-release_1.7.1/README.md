This is the WIKI of the Mazebot Simulation Tool
